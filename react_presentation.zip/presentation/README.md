
# React 18.2 Features Presentation

## Setup

To run this presentation:

1. Install dependencies:
   ```bash
   npm install
   ```

2. To start the presentation in development mode:
   ```bash
   npm start
   ```

3. To build the presentation for production:
   ```bash
   npm run build
   ```

Navigate to `localhost:8000` to view the presentation.
