
import React from 'react';

const MyComponent = () => {
  return <div style={{ marginTop: '20px', fontSize: '20px', color: 'blue' }}>This is a custom React component showing how simple it is to integrate React components into your MDX Deck presentation.</div>;
};

export default MyComponent;
